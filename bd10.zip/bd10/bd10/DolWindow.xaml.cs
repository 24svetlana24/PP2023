﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bd10
{
    /// <summary>
    /// Логика взаимодействия для DolWindow.xaml
    /// </summary>
    public partial class DolWindow : Window
    {
        bd10Entities1 Add { get; set; }
        public DolWindow()
        {
            InitializeComponent();
            Loader();
        }
        public void Loader()
        {
            Add = new bd10Entities1();
            Dol.ItemsSource = Add.Dol.ToList();
        }
        private void qeq(object sender, RoutedEventArgs e) /*Кнопка  Удаления*/
        {
            Add = new bd10Entities1();
            Dol item = Dol.SelectedItem as Dol;
            try
            {
                Dol ser = Add.Dol.Where(c => c.id == item.id).Single();
                Add.Dol.Remove(ser);
                Add.SaveChanges();

                MessageBox.Show("Данные успешно удалены");
                refreshdatagrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void refreshdatagrid() /*обновление таблицы*/
        {
            Add = new bd10Entities1();
            Dol.ItemsSource = Add.Dol.ToList();
            Dol.Items.Refresh();
        }


        // Нажатие кнопки "Вернуться назад"
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window1 f1 = new Window1();
            f1.Show();
            Close();
        }

        // Нажатие кнопки "Добавить запись"
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            AddDol addDolWindow = new AddDol();
            addDolWindow.Owner = this;
            addDolWindow.Show();
        }

        private void SaveChangesButton_Click(object sender, RoutedEventArgs e)
        {
            //Users user = new Users();
            //user = qqq.SelectedItem as Users;

            //user.Role = (b1.SelectedItem as Rol).ID;
            //user.FIO = a1.Text;
            //user.Login = a2.Text;
            //user.Password = a3.Text;
            //MessageBox.Show("ИБП успешно добавлен в базу!");
            //Add.SaveChanges();
            //qqq.ItemsSource = Add.Users.ToList();

            //b1.SelectedValue = -1;
        }
    }
}
