﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bd10
{
    /// <summary>
    /// Логика взаимодействия для AddDol.xaml
    /// </summary>
    public partial class AddDol : Window
    {
        bd10Entities1 Database;
        public AddDol()
        {
            InitializeComponent();
            Database = new bd10Entities1();
            PodrazdelComboBox.ItemsSource = Database.Podrazdel.ToList();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Dol dol = new Dol();
            dol.id = Int16.Parse(IdTextBox.Text);
            dol.name = nameTextBox.Text;
            dol.oklad = okladTextBox.Text;
            dol.Podrazdel = (PodrazdelComboBox.SelectedItem as Podrazdel);

            Database.Dol.Add(dol);
            Database.SaveChanges();
            (this.Owner as DolWindow).Loader();

        }
    }
}
