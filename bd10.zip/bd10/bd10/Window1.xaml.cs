﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bd10
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        bd10Entities1 Add { get; set; }
    public Window1()
        {
            InitializeComponent();
            Loader();
        }

        public void Loader()
        {
            Add = new bd10Entities1();
            qqq.ItemsSource = Add.Users.ToList();
            b1.ItemsSource = Add.Rol.ToList();
        }

        private void qeq(object sender, RoutedEventArgs e) /*Кнопка  Удаления*/
        {
            Add = new bd10Entities1();
            Users item = qqq.SelectedItem as Users;
            try
            {
                Users ser = Add.Users.Where(c => c.ID == item.ID).Single();
                Add.Users.Remove(ser);
                Add.SaveChanges();

                MessageBox.Show("Данные успешно удалены");
                refreshdatagrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void refreshdatagrid() /*обновление таблицы*/
        {
            Add = new bd10Entities1();
            qqq.ItemsSource = Add.Users.ToList();
            qqq.Items.Refresh();
        }

        // Добавление
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            AddUserWindow addUserWindow = new AddUserWindow();
            addUserWindow.Owner = this;
            addUserWindow.Show();
        }

        private void SaveChangesButton_Click(object sender, RoutedEventArgs e) // Сохранить изменения    
        {
            Users user = new Users();
            user = qqq.SelectedItem as Users;

            user.Role = (b1.SelectedItem as Rol).ID;
            user.FIO = a1.Text;
            user.Login = a2.Text;
            user.Password = a3.Text;
            MessageBox.Show("ИБП успешно добавлен в базу!");
            Add.SaveChanges();
            qqq.ItemsSource = Add.Users.ToList();
            
            b1.SelectedValue = -1;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            SotrudnikiWindow f4 = new SotrudnikiWindow();
            f4.Show();
            Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            DolWindow f3 = new DolWindow();
            f3.Show();
            Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            PodrazdelWindow f2 = new PodrazdelWindow();
            f2.Show();
            Close();

        }
    }
}

