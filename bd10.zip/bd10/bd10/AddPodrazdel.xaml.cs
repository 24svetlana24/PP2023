﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace bd10
{
    /// <summary>
    /// Логика взаимодействия для AddPodrazdel.xaml
    /// </summary>
    public partial class AddPodrazdel : Window
    {
        bd10Entities1 Database;

        public AddPodrazdel()
        {
            InitializeComponent();
            Database = new bd10Entities1();

        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Podrazdel podrazdel = new Podrazdel();
            podrazdel.id = Int16.Parse(IdTextBox.Text);
            podrazdel.name = nameTextBox.Text;
            podrazdel.sostav = sostavTextBox.Text;
            Database.Podrazdel.Add(podrazdel);
            Database.SaveChanges();
            (this.Owner as PodrazdelWindow).Loader();
        }
    }
}
